# Project context: multi-sensor "health twin" thesis

Copy this file into the root of the app repository on Ubuntu, so Claude loads it in every session. It summarises
work done on Windows (Oct 2026) that is not in the app repository.

## The study

* **Thesis:** a digital twin of a person's important contexts, covering both the **sensor system** and
  **health insight**. Models must run on a **phone**.
* **Location and time:** Dhaka, Bangladesh; local time Asia/Dhaka (UTC+6); October 2026.
* **Sensors:**
  * two instrumented insoles (R = `GAIT`, L = `GAIT_LEFT`): heel / Met1 / Met5 FSRs plus an IMU, ~112 Hz
  * environment node: CO₂, temperature, RH, PM1/2.5/10, dBA; one sample per 10 s
  * posture cushion
  * smart bottle (weight + capacitive + fused volume)
  * phone GPS
  * Xiaomi Smart Band 10 via Gadgetbridge → Health Connect export
* **App:** the recorder app is version 0.0.1, most likely Android. Data formats: `docs/DATA_FORMATS.md`.
* **Participants:**
  * **P1 Hemel**: male, 1.71 m (5 ft 7.5 in), 77 kg; days 1–8 (8–15 Oct 2026); walks, metro, rickshaw.
  * **P2 Spriha**: female, 1.47 m (4 ft 10 in), 68 kg (her day-1 report wrongly says 1.58 m / 67 kg); days 1–4
    (17–20 Oct); mostly rickshaws. Her insoles were deliberately not worn on day 4.

## Where things are

| Item | Location |
|---|---|
| Raw data + Python pipeline | Windows: `G:\MY COOL EXPERIMENTS\Thesis_data_collection\` (`Hemel/day_N`, `spriha/day_N`, `Hemel/pipeline/*.py`, `Hemel/ml/`, `participants/`) |
| Copy of pipeline code | `reference/pipeline/` |
| Reports (PDF) | `reference/reports/` (two-participant comparison, ML report, example daily reports) |
| ML results | `reference/ml/` (`deploy.json` = phone sizes/latency; `*_results.json`) |
| Sample data | `sample_data/` (one session per participant, trimmed) |
| App work to do | `docs/APP_FIXES.md` (data reliability) and `docs/FEATURE_HEALTH_TWIN.md` (alerts, reminders, daily report UI) |
| Alert thresholds | `config/thresholds.json` |
| UI mockup | `mockups/daily_report.html` (Hemel day 7, real numbers) |

The pipeline order for one day is:
1. `day_N/analysis.py` (calls `daily_analysis.py`, configured by `day_config.json`)
2. `compare_days.py <subject_dir> N`
3. `relationships.py <subject_dir> N` (run after compare_days, which clears its output folder)
4. `walk_hydration.py`
5. `compare_participants.py`
6. `participants_report.py`

Reports are hand-written LaTeX, compiled with pdflatex.

## Standing rules from the user

* **Explain the strategy before running any ML step.** The user wants to learn the why and the what.
* **Report honestly.** When a hypothesis was not supported (water before walking), keep the result and explain it.
  Never drop data because it weakens a pattern.
* **Drinking logs:** every drink list is the **smart-bottle log**; never call it "manual".
* **Bottle stream:** Fused_mL is the main channel; Cap_mL == 500 is invalid; removals count as drinks.
* **Times without am/pm** are taken in chronological order.
* **Temperature:** the pipeline applies −5 °C (`temp_offset_c`). It is known to be too small after a cold start;
  excluding the warm-up is deferred to the final write-up.
* **Posture:** the pipeline relabels LEAN_FORWARD as upright (Hemel's calibration).
* **Figures:** A4 12 pt LaTeX report; width = \textwidth = 5.4 in, height ≤ 4.2 in; all text 10–12 pt; vector PDF +
  300 dpi PNG; a caption for each; split big figures; print-friendly (hatches and markers, not colour alone).
* **On Windows,** never rewrite UTF-8 Python files with PowerShell Get-Content/WriteAllText (it caused mojibake).

## Key findings so far (for the app and the thesis)

* **Heart rate vs step rate** is the one relationship that replicates across people:
  * within-day r = 0.30 (Hemel) and 0.29 (Spriha); slope 0.20 and 0.18 bpm per step/min
  * positive on all 12 days
  * it holds only at ≥ 10-min scale; minute-to-minute changes are unrelated
* **Sleeping HR:** 62.3 ± 1.7 bpm (Hemel) vs 70.7 ± 0.9 bpm (Spriha), with no overlap; a stable personal baseline.
* **Gait vs body size:** her strides are 8.8 % shorter in time. Scaling by √(leg length / g) leaves 1.6 %, so the
  difference is mostly body size.
* **Water before walking (Hemel):** the apparent effect was a time-of-day confound. The planned day-8 test (500 mL
  before a morning walk) gave the largest HR rise; the partial ρ after time of day is 0.04.
* **Environment:**
  * Dhaka PM2.5 was 50–80 µg/m³ almost everywhere.
  * Events: restaurant 357, closed market 514, smoke-filled space 716, soldering fumes 3,333 (the sensor ceiling).
  * Metro CO₂ 1,500–2,500 ppm.
  * Spriha's closed evening room: CO₂ +146 ppm/h; temperature and absolute humidity fell together, consistent with AC.
* **Sensor issues:**
  * the half-rate insole makes inter-insole timing invalid; per-foot measures stay valid
  * FSRs replaced: Hemel right Met1, Spriha all right
  * the left forefoot FSRs clip at 4,095
  * environment-node self-heating (+10–12 °C after a cold start)
  * CO₂ reads low
  * optical HR cadence lock while walking
  * the band's sleep record is incomplete for Spriha
* **ML** (leave-one-day-out; full details in `reference/reports/ml_report.pdf`):
  * activity GBM macro-F1 0.79
  * place logistic regression 0.67
  * heel-strike TCN F1 0.915
  * IMU toe-off rule at the label noise floor
  * slip ranked 1st of 18,261 steps by impact z (z = 6.12; the next-highest step 5.98)

## Next work (on Ubuntu)

Implement `docs/APP_FIXES.md`, then `docs/FEATURE_HEALTH_TWIN.md` in the app, using `config/thresholds.json`. Check
ported analysis functions against the Python pipeline on `sample_data/`.
